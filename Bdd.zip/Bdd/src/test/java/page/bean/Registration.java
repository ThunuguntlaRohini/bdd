package page.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Registration {

	WebDriver wd;

	// initiating Elements
	public Registration(WebDriver webdriver) {
		this.wd = webdriver;
		PageFactory.initElements(wd, this);
	}

	public Registration() {
		super();
		// TODO Auto-generated constructor stub
	}

	@FindBy(name = "name")
	@CacheLookup
	WebElement name;

	@FindBy(name = "mobile")
	@CacheLookup
	WebElement mobile;

	@FindBy(name = "email")
	@CacheLookup
	WebElement email;

	@FindBy(name = "address")
	@CacheLookup
	WebElement address;

	@FindBy(name = "gender")
	@CacheLookup
	WebElement gender;
	
	@FindBy(name = "btn")
	@CacheLookup
	WebElement submit;
	

	public WebElement getSubmit() {
		return submit;
	}

	public void setSubmit() {
		submit.click();
	}

	public WebElement getName() {
		return name;
	}

	public void setName(String name1) {
		name.sendKeys(name1);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile1) {
		mobile.sendKeys(mobile1);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email1) {
		email.sendKeys(email1);
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address1) {
		address.sendKeys(address1);
	}

	public WebElement getGender() {
		return gender;
	}

	public void setGender(String gender1) {
		gender.sendKeys(gender1);
	}

}
