package page;

import java.util.List;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import page.bean.Registration;

public class StepDef {

	static Registration registration = null;
	WebDriver driver;

	@Given("^user is on login page$")
	public void user_is_on_login_page() {
		// Write code here that turns the phrase above into concrete actions
		// System.setProperty("WebDriver.chromedriver", ‪"C:\\chromedriver.exe");
		driver = new ChromeDriver();
	}

	@Then("^check the title$")
	public void check_the_title() {
		// Write code here that turns the phrase above into concrete actions
		String title = driver.getTitle();
		if (title.equals("registration")) {
			System.out.println("user is on correct page");
		} else {
			System.out.println("not matched user is in wrong page");
		}
	}

	@Given("^user is on registration page$")
	public void user_is_on_registration_page() {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^name is empty$")
	public void name_is_empty() {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^user clicks submit$")
	public void user_clicks_submit() {
		// Write code here that turns the phrase above into concrete actions
		registration.setSubmit();
	}

	@Then("^display error message$")
	public void display_error_message() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		System.out.println(alertMessage);
	}

	@When("^user entered invalid mobile number$")
	public void user_entered_invalid_mobile_number(DataTable mobile1) throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions

		registration.setName("Rohini");
		Thread.sleep(1000);

		List<String> mobList = mobile1.asList(String.class);
		String data = null;
		for (String mobile : mobList) {
			data = mobile;
			registration.getMobile().clear();
			registration.setMobile(mobile);
			Thread.sleep(1000);
			registration.setSubmit();

			if (Pattern.matches("^[7-9]{1}[0-9]{9}$", data)) {
				System.out.println("Matching ");
			} else {
				String alertMessage = driver.switchTo().alert().getText();
				Thread.sleep(1000);
				driver.switchTo().alert().accept();
				System.out.println("not matched " + alertMessage);

			}
		}
		registration.setSubmit();

	}

	@When("^email is empty$")
	public void email_is_empty() {

	}

	@When("^user entered invalid Email$")
	public void user_entered_invalid_Email(DataTable arg1) {

		// For automatic transformation, change DataTable to one of
		// List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		// E,K,V must be a scalar (String, Integer, Date, enum etc)

	}

	@When("^address is empty$")
	public void address_is_empty() {

	}

	@When("^gender is not selected$")
	public void gender_is_not_selected() {

	}

	@When("^user entered invalid name$")
	public void user_entered_invalid_name(DataTable arg1) {

		// For automatic transformation, change DataTable to one of
		// List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		// E,K,V must be a scalar (String, Integer, Date, enum etc)

	}

	@When("^mobile is empty$")
	public void mobile_is_empty() {

	}

	@When("^user enters valid data$")
	public void user_enters_valid_data() {

	}

	@Then("^navigate to next pageS$")
	public void navigate_to_next_pageS() {

	}

}